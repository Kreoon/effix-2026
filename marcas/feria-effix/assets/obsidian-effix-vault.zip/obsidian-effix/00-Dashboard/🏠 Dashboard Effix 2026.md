# 🏠 Dashboard — Feria Effix 2026

> **Última actualización:** Marzo 2026  
> **Evento:** Feria Effix 2026 — 16, 17 y 18 de Octubre · Plaza Mayor, Medellín  
> **Rol:** Marketing & Advertising — Grupo Effi (EffiX S.A.S. · NIT 901497359)

---

## 📌 Estado actual del proyecto

| Área | Estado | Nota |
|------|--------|------|
| Google Ads cuenta | ✅ Creada | ID: 356-853-8992 |
| GA4 conectado | ✅ Activo | G-CRXZ50VX7D |
| GTM instalado | ✅ Instalado | GTM-TLRMK246 |
| Conversiones configuradas | ✅ Listo | 2 tags (full + cuotas) |
| Campaña Search Marca | ⏸️ Pausada | Esperando certificación de política |
| Certificación Google (tickets) | 🔄 En proceso | 3–7 días hábiles |
| Páginas de gracias WordPress | ⚠️ Pendiente | /gracias-black-completo y /gracias-black-cuotas |
| Redirects Wompi / ePayco | ⚠️ Pendiente | Configurar post-pago |
| Meta Ads | ✅ Activo | Canal principal de adquisición |
| Microsoft Clarity | 📋 Planeado | Instalación vía GTM |

---

## 🗺️ Navegación del vault

### 🎯 Estrategia
- [[Google Ads — Estrategia Feria Effix 2026]]
- [[Meta Ads — Análisis y Estrategia]]
- [[VSL Playbook — LatAm]]

### ⚙️ Configuración Técnica
- [[Bitácora Google Ads — Configuración Completa]]
- [[Tracking — GA4, GTM y Conversiones]]
- [[Guía Implementación Google Ads]]

### 🔬 Investigación
- [[Feria Effix — Investigación Completa]]
- [[Grupo Effi — Ecosistema y Análisis Estratégico]]
- [[Grupo Effi — Imperio de Marketing con Eventos]]

### 📣 Campañas Activas
- [[Campaña Search Marca Effix]]
- [[EffiWoman Fest — Estrategia]]

### ✍️ Creativos
- [[Hooks y Copys Aprobados]]

---

## 🔑 Datos críticos del proyecto

### Google Ads
- **ID cuenta:** 356-853-8992
- **Moneda:** COP (irreversible)
- **Purchase conversion ID:** AW-17981312035
- **Label:** RTbrCMHZpoYcEKOYlP5C

### GA4
- **Property ID:** G-CRXZ50VX7D
- **Stream ID:** 13248640925

### GTM
- **Container ID:** GTM-TLRMK246

### Triggers de conversión
- **Black completo:** URL contiene `gracias-black-completo` → COP $3,997,000
- **Black cuotas:** URL contiene `gracias-black-cuotas` → COP $1,000,000

---

## 🎫 Tickets Feria Effix 2026

| Tipo | Precio COP | Precio USD |
|------|-----------|------------|
| Pasaporte 3 días | $201,300 | ~$50 |
| Black | $1,155,000 | ~$997 |
| Niños menores 12 | Gratis | — |

---

## 📅 Próximas acciones

- [ ] Crear páginas WordPress `/gracias-black-completo` y `/gracias-black-cuotas`
- [ ] Configurar redirects post-pago en Wompi y ePayco
- [ ] Esperar aprobación certificación Google (política de venta de tickets)
- [ ] Activar campaña Search Marca una vez aprobada
- [ ] Implementar Microsoft Clarity vía GTM
- [ ] Iniciar Fase 2 campañas (Consideration) según guía operacional

---

## 🌎 Expansión geográfica planeada

Colombia · Ecuador · República Dominicana · El Salvador · Perú · México · Chile · Costa Rica · Panamá · Guatemala  
❌ Venezuela excluida (capacidad de pago)
