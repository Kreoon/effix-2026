# 📝 Plantilla — Resumen de Sesión con Claude

> Copia esta nota al final de cada sesión importante y completa los campos.  
> **Tags:** #sesion #resumen

---

## Fecha: {{fecha}}

## ¿Qué trabajamos hoy?

_Describe en 2-3 líneas el tema principal de la sesión._

---

## Decisiones tomadas

- 
- 
- 

---

## Documentos generados

| Documento | Tipo | Ubicación |
|-----------|------|-----------|
|  |  |  |

---

## Acciones pendientes

- [ ] 
- [ ] 
- [ ] 

---

## Aprendizajes clave

_¿Qué aprendiste o confirmaste en esta sesión?_

---

## Próxima sesión

_¿Qué quieres trabajar la próxima vez?_

---

## Notas adicionales

