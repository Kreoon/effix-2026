# Bitácora Google Ads — Configuración Completa

> **Estado:** ✅ Configurado · ⏸️ Campaña pausada por certificación  
> **Última actualización:** Marzo 2026  
> **Tags:** #google-ads #configuracion #tracking #conversiones

---

## Datos de la cuenta

| Dato | Valor |
|------|-------|
| ID cuenta Google Ads | **356-853-8992** |
| Tipo de cuenta | Organization profile |
| Entidad legal | EffiX S.A.S. |
| Moneda | COP (irreversible) |
| GA4 Property | **G-CRXZ50VX7D** |
| GA4 Stream ID | 13248640925 |
| GTM Container | **GTM-TLRMK246** |

> ⚠️ La moneda COP es irreversible. Si en el futuro se quiere facturar en USD hay que crear una cuenta nueva.

---

## Estado de vinculaciones

- ✅ GA4 ↔ Google Ads vinculados
- ✅ Publicidad personalizada habilitada
- ✅ GTM instalado en feriaeffix.com
- ✅ Tag de remarketing activo en todas las páginas

---

## Conversiones configuradas

### Conversion 1 — Black Completo (pago total)

| Campo | Valor |
|-------|-------|
| Nombre | Compra Black Completo |
| Conversion ID | AW-17981312035 |
| Label | RTbrCMHZpoYcEKOYlP5C |
| Valor | COP $3,997,000 |
| Trigger GTM | URL contiene `gracias-black-completo` |

### Conversion 2 — Black Cuotas (primer pago)

| Campo | Valor |
|-------|-------|
| Nombre | Compra Black Cuotas |
| Conversion ID | AW-17981312035 |
| Label | RTbrCMHZpoYcEKOYlP5C |
| Valor | COP $1,000,000 |
| Trigger GTM | URL contiene `gracias-black-cuotas` |

> 💡 **Decisión arquitectural:** Dos tags separados permiten análisis comparativo entre modalidades de pago.

---

## Páginas pendientes de crear (WordPress)

- [ ] `/gracias-black-completo` — página de agradecimiento pago total
- [ ] `/gracias-black-cuotas` — página de agradecimiento pago en cuotas

> Sin estas páginas los triggers no funcionan y no se registran conversiones.

---

## Redirects pendientes de configurar

- [ ] **Wompi:** configurar redirect post-pago a `/gracias-black-completo`
- [ ] **ePayco:** configurar redirect post-pago según modalidad

---

## Campaña Search — Marca Effix

| Dato | Valor |
|------|-------|
| Nombre | [Search] Marca Effix |
| Estado | ⏸️ Pausada |
| Tipo | Search (manual CPC) |
| Match type | Exact match |
| Presupuesto diario | COP $88,000 |
| Motivo pausa | Certificación política venta de tickets Google |
| Tiempo estimado certificación | 3–7 días hábiles |

**Keywords exactas configuradas:**
- [feria effix]
- [feriaeffix]
- [feria ecommerce medellín]
- [evento ecommerce colombia]
- [feria effix 2026]

---

## Principios de la Fase 1

1. **Solo Search** — sin AI Max ni Performance Max
2. **Control manual** primero — automatización después de tener datos limpios
3. **Exact match** — máximo control de búsquedas
4. **Datos limpios** antes de escalar

---

## Roadmap de fases

### Fase 1 — Activación (pendiente certificación)
- Campaña Search Marca activa
- Validar conversiones
- Establecer CPA base

### Fase 2 — Consideración
- Campañas Display y Discovery
- Audiencias de remarketing
- Expansión geográfica

### Fase 3 — Urgencia (Sep–Oct 2026)
- Performance Max
- Presupuesto aumentado
- Countdown timers

---

## Expansión geográfica planeada

**10 países objetivo:**
Colombia · Ecuador · República Dominicana · El Salvador · Perú · México · Chile · Costa Rica · Panamá · Guatemala

**Excluido:** Venezuela (capacidad de pago insuficiente)

---

## Referencias cruzadas

- [[Google Ads — Estrategia Feria Effix 2026]]
- [[Guía Implementación Google Ads]]
- [[🏠 Dashboard Effix 2026]]
