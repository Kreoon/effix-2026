# Google Ads — Estrategia Feria Effix 2026

> **Estado:** Fase 1 lista · Esperando certificación Google  
> **Tags:** #google-ads #estrategia #search #sem

---

## Contexto

Google Ads es un canal complementario al ecosistema comunitario de Grupo Effi (no un driver standalone). La estrategia prioriza control manual antes de introducir automatización, y está diseñada para capturar demanda de intención alta (búsquedas de marca y evento).

---

## Ticket objetivo: Black — USD $997

El ticket Black es el objetivo principal de conversión de Google Ads por su alto margen y CPA justificado.

**Incluye:**
- Acceso 3 días completos
- Comidas incluidas
- 9 mentorías personalizadas
- Networking premium
- Zonas exclusivas

**Precio:** COP $1,155,000 (~USD $997)

---

## Estructura de campañas por fase

### Fase 1 — Activación (actual)

| Campaña | Tipo | Estado | Presupuesto/día |
|---------|------|--------|----------------|
| [Search] Marca Effix | Search | ⏸️ Pausada | COP $88,000 |

**Objetivo:** Capturar búsquedas de marca con máximo control

### Fase 2 — Consideración (posterior)

| Campaña | Tipo | Objetivo |
|---------|------|---------|
| [Display] Remarketing | Display | Reimpactar visitantes |
| [Discovery] Audiencias frías | Discovery | Consideración |

### Fase 3 — Urgencia (Sep–Oct 2026)

| Campaña | Tipo | Objetivo |
|---------|------|---------|
| [PMax] Conversión | Performance Max | Maximizar conversiones |
| [Search] Evento general | Search | Captar últimas búsquedas |

---

## Principios estratégicos

1. **Manual antes de automático** — Phase 1 sin AI Max ni PMax para construir data limpia
2. **Alta tolerancia CPA** — ticket de USD $997 justifica CPAs altos vs productos de bajo valor
3. **Dos conversiones separadas** — full payment vs cuotas para análisis comparativo
4. **Activos existentes > nuevos** — GA4 con data histórica preservada, no se creó nueva propiedad
5. **Venezuela excluida** — capacidad de pago insuficiente para este producto
6. **VSL para YouTube, assets directos para Search/Display** — no usar VSL larga en canales de intención directa

---

## Copy RSA — Campaña Marca (activo)

**Headlines (15 disponibles, se usan los mejores):**
- Feria Effix 2026 | Compra tu Entrada
- La Mayor Feria Ecommerce de Latam
- 16-18 Oct · Plaza Mayor Medellín
- Ticket Black desde $997 USD
- 200+ Speakers | 8 Auditorios
- Feria Effix Oficial | Entradas Aquí
- Ecommerce · Dropshipping · Marketing
- 50,000+ Asistentes Esperados
- Acceso 3 Días + Mentorías Premium
- Compra Oficial feriaeffix.com

**Descriptions (4 disponibles):**
- Vive la experiencia más grande del ecommerce en Latinoamérica. Speakers internacionales, networking y conocimiento para escalar tu negocio. Medellín, Octubre 2026.
- Feria Effix 2026: 16, 17 y 18 de Octubre en Plaza Mayor. Más de 200 expertos, 8 auditorios simultáneos y el ecosistema de negocios digitales más grande de la región.
- Ticket Black: acceso completo, comidas incluidas, mentorías personalizadas y zonas VIP exclusivas. La inversión más inteligente para tu negocio digital este año.
- 5 ediciones, 140,000 asistentes acumulados. En 2026 será más grande. Asegura tu lugar antes de que se agoten. Compra oficial en feriaeffix.com.

---

## Sitelinks configurados

| Sitelink | URL destino |
|----------|------------|
| Compra tu Pasaporte 3 Días | /pasaporte |
| Ticket Black Premium | /black |
| Programa y Speakers 2026 | /programa |
| Información para Empresas | /stands |

---

## KPIs objetivo (por definir con data real)

| Métrica | Referencia inicial |
|---------|-------------------|
| CTR Search Marca | >8% |
| CPC promedio | <COP $2,500 |
| CVR a página | >3% |
| CPA Black ticket | Por determinar |
| ROAS objetivo | >3x |

---

## Referencias cruzadas

- [[Bitácora Google Ads — Configuración Completa]]
- [[Tracking — GA4, GTM y Conversiones]]
- [[Meta Ads — Análisis y Estrategia]]
- [[🏠 Dashboard Effix 2026]]
