# Meta Ads — Análisis y Estrategia

> **Estado:** ✅ Canal activo — principal canal de adquisición  
> **Dataset:** 16 campañas · ~984 registros · COP $2.3M invertidos (Jun 2025 – Mar 2026)  
> **Tags:** #meta-ads #facebook #instagram #pauta

---

## Datos del dataset histórico

| Dato | Valor |
|------|-------|
| Campañas analizadas | 16 |
| Total registros | ~984 |
| Inversión total | COP $2,300,000 approx |
| Período | Junio 2025 – Marzo 2026 |
| Archivo | EVENTOSGRUPOEFFI.csv |

---

## Documentos de análisis generados

- `Analisis_Campanas_GrupoEffi_v2.docx`
- `Estrategia_Eventos_Creativos_GrupoEffi.docx`
- `EffiWoman_Fest_Estrategia_Creativos.docx`

---

## EffiWoman Fest — Campaña activa

| Dato | Valor |
|------|-------|
| Evento | EffiWoman Fest |
| Fecha | 20 de Marzo 2026 |
| Meta de registros | 500 |
| Estado estrategia | ✅ Entregada |
| Documento | EffiWoman_Fest_Estrategia_Creativos.docx |

---

## Principios de la estrategia Meta para Effix 2026

### Segmentación
- Emprendedores digitales 25–45 años
- Intereses: ecommerce, dropshipping, marketing digital, emprendimiento
- Lookalikes de compradores anteriores de Feria Effix
- Retargeting a visitantes de feriaeffix.com

### Creativos que funcionan
- UGC (User Generated Content) de asistentes anteriores
- Testimonios en video de ediciones pasadas
- Clips de speakers reconocidos (Jürgen Klarić, Vilma Núñez)
- FOMO: imágenes de aforo lleno, stands, networking
- Countdown timers conforme se acerca octubre

### Estructura de campaña recomendada
```
Campaña 1 — Tráfico frío (Awareness)
  └── Conjunto 1: Intereses ecommerce
  └── Conjunto 2: Lookalike 1% compradores

Campaña 2 — Consideración (Engagement)
  └── Conjunto 1: Visitantes web 30 días
  └── Conjunto 2: Interactuaron con perfil IG

Campaña 3 — Conversión (Purchase)
  └── Conjunto 1: Retargeting caliente
  └── Conjunto 2: Lookalike 2% compradores
```

---

## Objetivos de conversión Meta

| Ticket | Precio | Objetivo Meta |
|--------|--------|--------------|
| Pasaporte 3 días | COP $201,300 | Volumen alto |
| Black | COP $1,155,000 | CPA justificado |

---

## Métricas históricas (referencia)

> Datos de las 16 campañas analizadas del dataset

- **CVR registros:** Variable según campaña (ver análisis completo)
- **CPM promedio:** Por calcular del dataset
- **CPC promedio:** Por calcular del dataset
- **Costo por resultado:** Por calcular del dataset

---

## Notas importantes

- Meta Ads es el canal primario de adquisición — Google Ads es complementario
- El ecosistema cautivo de 20K clientes Grupo Effi reduce costo de adquisición
- Los embajadores con código único generan un canal orgánico de distribución paralelo

---

## Referencias cruzadas

- [[Google Ads — Estrategia Feria Effix 2026]]
- [[Feria Effix — Investigación Completa]]
- [[🏠 Dashboard Effix 2026]]
