# Feria Effix — La Mayor Feria de Ecommerce de Latinoamérica

> **Fuente:** Investigación interna Grupo Effi · Actualizada Febrero 2026  
> **Tags:** #feria #evento #ecommerce #latam #medellín

---

## Datos generales

- **Edición 2026:** 6ª edición
- **Fecha:** 16, 17 y 18 de Octubre de 2026
- **Lugar:** Plaza Mayor, Medellín, Colombia
- **Posicionamiento:** La feria de ecommerce presencial más grande de América Latina
- **Organizador:** Grupo Effi (EffiX S.A.S., NIT 901497359)
- **Fundadores:** Juan David Carmona, Stevenson Rivera, Sara Montoya
- **Sede:** TV 39B Circular 76-19, Laureles, Medellín

---

## Histórico de crecimiento

| Edición | Año | Asistentes |
|---------|-----|-----------|
| 1ª | 2021 | 2,580 |
| 2ª | 2022 | 14,000 |
| 3ª | 2023 | 35,733 |
| 4ª | 2024 | 41,991 |
| 5ª | 2025 | 49,256 |
| **6ª** | **2026** | **Meta: 60,000+** |

**Total acumulado:** 140,000+ asistentes en 5 ediciones

---

## Escala de la edición 2025

- 348 stands
- 214 speakers
- US$1.5M+ de inversión
- US$23.1M de impacto económico para Medellín
- 1,200 empleos directos + 3,627 indirectos

---

## Precios de tickets 2026

| Ticket | Precio COP | Precio USD approx |
|--------|-----------|------------------|
| Pasaporte 3 días | $201,300 | ~$50 |
| Black | $1,155,000 | ~$997 |
| Niños menores 12 | Gratis | — |

**Black incluye:** Comidas, 9 mentorías personalizadas, networking premium, zonas exclusivas

**Plataforma de venta:** LaTiquetera  
**Contacto:** gerencia@feriaeffix.com

---

## Pabellones temáticos

| Pabellón | Color | Temática |
|----------|-------|---------|
| Verde | 🟢 | Liderazgo y escalamiento |
| Amarillo | 🟡 | Marketing, ventas, IA y conversión |
| Rojo | 🔴 | Emprendedores avanzados y desarrollo personal |

8 auditorios simultáneos

---

## Temas cubiertos

- Ecommerce y dropshipping
- Marketing digital y IA
- Logística y fulfillment
- UGC y creación de contenido
- Neuromarketing
- Marca personal
- Crypto
- Marketplaces (MercadoLibre)
- Import/export
- Formalización empresarial

---

## Speakers destacados (históricos/recurrentes)

Jürgen Klarić · Vilma Núñez · Amadeo Lladós · Gabriel Beltrán · Rigoberto Urán · Mike Munzvil · Felipe Vergara · Juan Ads · Julián Otálora · Stevenson Rivera

---

## Sponsors principales

MercadoLibre · Mercado Pago · Envía · TCC · Servientrega · Inter Rapidísimo · Coordinadora · Taboola · SmartBeemo · MasterTools · Dropi · ROOT+CO · Comfama · Xhobbies

---

## Presencia digital

| Canal | Datos |
|-------|-------|
| Instagram | @feriaeffix — 382K+ seguidores |
| TikTok | 30K+ seguidores |
| YouTube | 110+ conferencias completas |
| Web | feriaeffix.com |

---

## Estrategias de crecimiento clave

1. **Ecosistema cautivo:** 20K clientes Grupo Effi son leads pre-calificados
2. **Programa de embajadores:** 20% comisión por ticket / 5% por stand / 2% por sponsorship
3. **Speakers como distribución:** 200+ speakers promocionan orgánicamente
4. **PR institucional:** 28+ entidades públicas/privadas (Alcaldía, Gobernación)
5. **Escalera de valor tickets:** 1 día → 3 días → VIP → Black
6. **YouTube evergreen:** 110+ conferencias generan descubrimiento todo el año
7. **Prueba social agresiva:** Posicionamiento "más grande del mundo" genera FOMO
8. **Co-marketing sponsors:** Sponsors promueven el evento a su propia base
9. **Anclaje cultural:** Movido a Octubre 2026 — señal de tracción independiente

---

## Medios que han cubierto la feria

El Tiempo · El Colombiano · El Espectador · La República · RCN · Teleantioquia · Portafolio · Pulzo · Valora Analitik · Marketing4eCommerce · MedellinGuru

---

## Nota importante

Grupo Effi es simultáneamente organizador, expositor y proveedor de soluciones tecnológicas en el evento. El ecosistema integrado es una ventaja competitiva pero también implica concentración de roles.
