# Grupo Effi: el conglomerado que construyó un imperio de marketing con eventos gratuitos

Grupo Effi ha diseñado una máquina de crecimiento inusual en el ecosistema tech latinoamericano: **un modelo de adquisición basado en comunidad y eventos, no en publicidad pagada tradicional**. Con más de US$100 millones en facturación anual, 20,000+ negocios conectados y 300+ empleados en 5 países, este conglomerado de Medellín invierte la lógica convencional del SaaS: en vez de gastar millones en ads digitales, destina su presupuesto más fuerte — **US$1.5M solo en Feria Effix 2025** — a crear experiencias presenciales gratuitas que alimentan un embudo de conversión orgánico extraordinariamente eficiente. El grupo opera un ecosistema verticalmente integrado (software ERP + logística + eventos + educación + bienes raíces + comunidad) donde cada empresa funciona como canal de adquisición para las demás, creando un efecto de red que sus competidores directos como Dropi o Siigo no pueden replicar fácilmente.

---

## La máquina de redes sociales: Instagram como pilar central con 490K+ seguidores combinados

La estrategia social de Grupo Effi es abrumadoramente Instagram-first. El ecosistema acumula **~490,000 seguidores combinados** en Instagram distribuidos estratégicamente: @feriaeffix lidera con **381K seguidores y 1,202 publicaciones** como cuenta insignia y principal imán de audiencia; @efficommerce aporta **96K seguidores con 625 publicaciones** enfocadas en producto; @effisystems suma **81K seguidores y 560 publicaciones**; y @grupoeffi complementa con **13K seguidores y 449 publicaciones** corporativas. En TikTok, @feriaeffix alcanza **30.3K seguidores con 217.1K likes**, mientras los fundadores mantienen cuentas activas — Juan David Carmona (@juandavidcarmonagomez) y Stevenson Rivera (@stevensonrivera) publican contenido de marca personal.

La distribución de contenido sigue un patrón claro: aproximadamente **50% es educativo** (webinars, tutoriales de ERP, estrategias de e-commerce), **20% testimonial y comunitario** (historias de éxito de usuarios, behind-the-scenes del equipo), **20% promocional** (countdowns de Feria Effix, venta de boletas, anuncios de speakers) y **10% motivacional/marca personal** de los fundadores. La frecuencia de publicación varía: @feriaeffix publica 3-5 veces por semana, @efficommerce y @grupoeffi entre 2-3 veces por semana, y el canal de YouTube "Grupo Effi" sube contenido semanalmente alineado con los eventos educativos de los miércoles.

**LinkedIn es el punto ciego más notable**: Grupo Effi tiene apenas 41 seguidores, Efficommerce 297 y Effisystems 73. Para un negocio B2B-SaaS que vende a empresarios y negocios, esta es una oportunidad masiva desaprovechada. En contraste, **WhatsApp es el verdadero hub comunitario** — cada touchpoint del ecosistema (Effiwoman, Efficaex, EffiLiving, registro a eventos) dirige al usuario a un grupo de WhatsApp, reflejando las preferencias comunicacionales del mercado latinoamericano. También mantienen un canal activo de Telegram ("DROPSHIPPING E ECOMMERCE EN COLOMBIA") para broadcasts y transmisiones en vivo.

---

## Publicidad pagada: un gasto moderado en un modelo dominado por lo orgánico

La evidencia indica que **Grupo Effi invierte significativamente menos en publicidad pagada de lo que su tamaño sugeriría**. No fue posible acceder directamente a la Meta Ad Library (requiere renderización JavaScript), pero la evidencia circunstancial es reveladora. Se detectó un **Facebook Pixel activo** (ID: 2136039990147940) en sitios de medios que cubren Effix, confirmando infraestructura publicitaria Meta en uso. El volumen de seguidores en Instagram para un SaaS B2B en LATAM sugiere amplificación pagada para construir y mantener estas audiencias. La integración profunda con el ecosistema Meta (EffiChat, automatización de WhatsApp Business) indica cuentas activas de Business Manager/Ads Manager.

**No se encontró evidencia significativa de Google Ads**. Las búsquedas de términos de marca y keywords relacionados ("ERP Colombia", "software ecommerce Colombia", "software de inventario") no mostraron anuncios patrocinados visibles. Tampoco se hallaron datos públicos de SEMrush o Ahrefs sobre campañas de búsqueda pagada para sus dominios. En cuanto a TikTok Ads, el contenido en @feriaeffix es primordialmente orgánico con promoción alrededor de temporadas de eventos, sin evidencia confirmada de campañas pagadas en TikTok Ad Library.

Un dato notable: **Taboola fue sponsor oficial de Feria Effix 2024**, sugiriendo una partnership que podría incluir campañas de native advertising/content recommendation. Esto, sumado al volumen coordinado de cobertura en más de **15 medios colombianos importantes**, sugiere una mezcla de PR orgánico y contenido patrocinado/paid PR.

Las estimaciones de gasto publicitario digital, basadas en evidencia indirecta, se sitúan en el rango de **US$250,000-500,000 anuales** para todo el grupo:

| Canal | Estimación anual | Evidencia |
|-------|-----------------|-----------|
| Meta Ads (IG/FB) | US$100K-250K | 490K+ seguidores IG combinados, Pixel activo |
| Google Ads | Mínimo-US$50K | Sin evidencia de campañas significativas |
| TikTok Ads | US$20K-50K | Estrategia orgánica dominante |
| PR/Contenido patrocinado | US$50K-150K | Cobertura coordinada en 15+ medios |
| Native (Taboola) | Incluido en sponsorship | Partnership directa |

Los **canales de adquisición principales**, en orden de impacto estimado, son: eventos presenciales y experienciales (Feria Effix como máquina #1), ecosistema Meta (Instagram + Facebook + WhatsApp), PR y earned media, marketing educativo/comunitario (eventos gratuitos semanales), TikTok orgánico, y por último Google/Search.

---

## Feria Effix: US$1.5M de inversión que genera US$3M en impacto económico

Feria Effix no es solo un evento — **es el principal canal de adquisición de todo el conglomerado**. Su crecimiento de asistencia ha sido exponencial: de **2,500 personas en 2021 a 42,000 en 2024**, con una meta de **50,000+ para la 5ta edición de agosto 2025** en Plaza Mayor, Medellín. La 6ta edición ya está anunciada para octubre 16-18 de 2026.

La inversión declarada de **US$1.5M+ para Effix 2025** cubre infraestructura del evento, venue, speakers internacionales, logística, producción y marketing promocional. El impacto económico proyectado supera **US$3 millones**, con generación de **1,200 empleos directos y 3,627 indirectos**. La edición 2024 generó por sí sola más de **US$1 millón en negocios** entre asistentes y expositores.

La estructura de boletas revela una sofisticada estrategia de monetización por tiers con precios escalonados:

- **Pasaporte General (3 días)**: acceso a 300+ stands, 160+ conferencias, zonas de networking
- **Entrada VIP**: inauguración, clausura, zona VIP con hidratación, asientos reservados, cena VIP, sesiones Mastermind, acceso backstage, zona de creación de contenido
- **Entrada Black (2026)**: pack completo de comidas (desayuno/almuerzo/cena buffet 3 días), 9 mentorías exclusivas con speakers durante comidas, zona Black Networking, descuentos hoteleros, artículos conmemorativos

La venta de boletas opera a través de **LaTiquetera** (latiquetera.com/site/effix) como partner oficial de ticketing con un portal branded dedicado, y también directamente vía feriaeffix.com. Los stands se venden por contacto directo vía WhatsApp y email (gerencia@feriaeffix.com), con paneles de 95cm x 240cm con perfiles de aluminio, tomas eléctricas, credenciales y pases de cortesía por tamaño.

Los speakers notables incluyen figuras como **Vilma Núñez** (influencer de marketing LATAM), **Gabriel Beltrán**, **Fernando Anzures**, **Rigoberto Urán** (ciclista celebrity) y **Jorge Serratos**, mezclando autoridad empresarial con pop culture para maximizar alcance. El evento se organiza en **tres pabellones temáticos**: Verde (liderazgo y escalamiento), Amarillo (marketing digital/IA/conversión) y Rojo (emprendimiento avanzado).

---

## El embudo de conversión: de contenido gratuito a lock-in ecosistémico

El funnel de Grupo Effi es un modelo de **education-led growth** extraordinariamente bien diseñado que convierte audiencia gratuita en usuarios pagos a través de múltiples touchpoints integrados.

**Etapa 1 — Awareness (gratuito)**: El prospecto descubre Grupo Effi a través de redes sociales, YouTube, eventos gratuitos de los miércoles (educativos) o martes (Effiwoman), el programa de referidos, o cobertura de prensa. Los eventos semanales en la sede de Medellín (Transversal 39B #76-19, Laureles) funcionan como top-of-funnel masivo con speakers invitados sobre temas como IA aplicada al negocio, finanzas corporativas, Excel/Power BI, y marketing digital.

**Etapa 2 — Captura de leads**: Cada touchpoint dirige a WhatsApp como CRM principal. Los formularios de registro (Google Forms) capturan nombre, cédula y número de WhatsApp. Los usuarios se unen a grupos comunitarios dedicados. El canal de YouTube "Grupo Effi" extiende el alcance global grabando y publicando las conferencias semanales.

**Etapa 3 — Educación y conversión inicial**: El usuario puede comprar **"La Fórmula Effix"** en Hotmart (calificación **4.4/5, 22 evaluaciones**, categoría Finanzas e Inversiones → Emprendimiento, vendido por EFFIX SAS, creado por Santiago Ospina). Este curso de 16+ módulos cubre mentalidad, estrategia digital, Instagram/TikTok, WhatsApp marketing, Google Ads, Facebook Ads, influencer marketing, Shopify, embudos de venta — y crucialmente, el **Módulo 15 enseña directamente el software Effi ERP**. Así, los estudiantes pagan por aprender y después se convierten en suscriptores del software. Alternativamente, el usuario se registra en el **Plan Free Ecommerce** (1 usuario, 1 empleado, 1 sucursal, funcionalidades limitadas) y completa la **Academia Effi ERP** en efficommerce.com.

**Etapa 4 — Suscripción pagada**: Upgrade desde Free hacia planes pagados con pricing escalonado para Colombia: Nuevo Emprendedor ($90,000 COP/mes, 8 empleados, 2 usuarios), Emprendedor ($120,000 COP/mes), Emprendedor Experto ($174,000 COP/mes), Empresario ($224,000 COP/mes). Add-ons incluyen facturación electrónica DIAN, nómina electrónica, paquetes SMS ($100,000 COP por 5,000 SMS), certificados de firma digital ($240,000 COP/año), y cuentas EffiChat para WhatsApp automatizado ($99,000 COP si excede 1,000 chats/mes).

**Etapa 5 — Lock-in ecosistémico**: El usuario utiliza Effi ERP para administración + Efficommerce para logística con carriers integrados (Envía Colvanes, Inter Rapidísimo, Domina, Servientrega, Coordinadora). Para expansión centroamericana → Efficaex con red logística de Cargo Expreso. Asiste a Feria Effix como expositor. Considera EffiLiving para espacio operativo físico en Medellín.

**Etapa 6 — Advocacy y referidos**: El programa de referidos está ingeniosamente integrado en el producto — **el Plan Free requiere actividad de referidos con al menos una comisión en los últimos 60 días** para mantener elegibilidad. Esto crea un loop viral donde los usuarios gratuitos generan nuevos leads orgánicamente.

---

## Seis empresas, una estrategia: cómo cada subsidiaria alimenta al ecosistema

**Effisystems** (effi.com.co) es el core tecnológico con un ERP 100% cloud que integra inventario, CRM, POS, producción, tesorería, nómina y dropshipping. Su estrategia freemium es el motor de adquisición principal: el plan gratuito atrae usuarios que naturalmente escalan a planes pagados conforme crecen. La app móvil está disponible en iOS (Effi ERP, ID 6444627708) pero **no se encontró versión Android** — una brecha crítica en un mercado donde Android domina más del 80% del mercado móvil latinoamericano. Las reseñas en App Store son mixtas, con quejas sobre funcionalidad y estabilidad.

**Efficommerce** (efficommerce.com) opera como brazo logístico con fulfillment, envíos multi-carrier, pago contra entrega (crítico para el e-commerce LATAM), tracking en tiempo real e infraestructura de dropshipping. Su marketing es operativamente transparente: publica propuestas comerciales por país, tracking de PQR vía Google Sheets públicos, mapas de cobertura, y diccionarios de estados de envío — herramientas que construyen confianza. La alianza estratégica con **Payoneer** para pagos internacionales atrae vendedores cross-border.

**Efficaex** (efficaex.efficommerce.com) replica el playbook colombiano en Centroamérica como joint venture con **Cargo Expreso** (30+ años en logística centroamericana). El evento histórico en Guatemala City en febrero 2025 con **500+ asistentes gratuitos** marcó la penetración del mercado, ofreciendo el mismo modelo: evento gratuito → grupo de WhatsApp → adopción de plataforma. La red de Cargo Expreso proporciona **99% de cobertura del territorio guatemalteco**.

**EffiLiving** (effiliving.com) es la apuesta más ambiciosa: un edificio de 11 pisos en **Calasanz, Medellín** — el primer edificio de Colombia dedicado exclusivamente al e-commerce — con una inversión de **US$5.2 millones** (~COP $19,177 millones). La construcción inició en junio 2024 con apertura proyectada en 2026. Combina rentas cortas para emprendedores visitantes, oficinas, coworking, estudios de creación de contenido y bodegas logísticas. Su marketing es completamente ecosistémico: se comercializa exclusivamente a la comunidad Effi a través de cobertura de prensa y WhatsApp.

**Effiwoman** funciona como la puerta de entrada emocional al ecosistema. Fundada por **Sara Montoya**, estos encuentros gratuitos cada martes a las 5pm en la sede de Grupo Effi operan con cupos limitados que frecuentemente se agotan, generando escasez y urgencia. Los temas rotan entre estrategia digital, logística, publicidad, liderazgo femenino y finanzas personales ("Relaciones que suman, finanzas que liberan"). Cada asistente se une a un grupo de WhatsApp dedicado, creando un canal directo para futuras promociones del ecosistema.

---

## Crecimiento orgánico: PR masivo, referidos virales y comunidad como foso competitivo

La cobertura mediática de Grupo Effi abarca los principales medios colombianos: **Revista Semana** (feature de noviembre 2025 destacando US$100M+ en facturación y proyección de Colombia como centro digital regional), **El Colombiano** (cobertura de Effix 2025 y su inversión de US$1.5M), **La República** (35,000 asistentes en Effix 2023), **Las2Orillas** (exposé de EffiLiving y los US$5.2M de inversión), **Portafolio**, **El Espectador**, **Teleantioquia**, **Valora Analitik**, **Publimetro**, **RCN Radio** y **Blu Radio**. La grupoeffi.com funciona como sala de prensa republicando artículos de estos medios.

Los fundadores distribuyen el peso mediático estratégicamente: **Juan David Carmona** es la cara pública principal, citado en toda la cobertura y activo en podcasts (apareció en Genios Podcast); **Stevenson Rivera** se posiciona como el cerebro técnico/ingeniero; y **Sara Montoya** lidera la narrativa de empoderamiento femenino vía Effiwoman. Esta distribución de roles maximiza la superficie de marca personal.

El programa de referidos/embajadores, lanzado formalmente en julio 2022, opera en dos niveles. Primero, el **Programa de Referidos Grupo Effi** donde usuarios reciben un enlace de referido para crear nuevas cuentas en el ecosistema, con la condición de generar al menos una comisión en 60 días para mantener el plan gratuito. Segundo, el programa **Embajadores de Feria Effix** (feriaeffix.com/embajadores/) específicamente para ventas de boletas del evento, con comisiones por ticket vendido. Los porcentajes exactos de comisión no están documentados públicamente, pero la integración del programa con el modelo de precios confirma que es un pilar estratégico central.

En el panorama competitivo, Grupo Effi ocupa un nicho difícil de replicar. Su competidor más directo es **Dropi** (plataforma de dropshipping colombiana — su CEO Luis Alberto Ramos asistió a Effix 2023). **Siigo y Alegra** compiten en ERP cloud para PyMES pero sin especialización e-commerce. **Shopify, VTEX y Mercado Libre** no son competidores sino plataformas con las que Effi se integra nativamente. La diferenciación clave es la **integración vertical completa** — ningún competidor ofrece simultáneamente ERP + logística + eventos + comunidad + bienes raíces.

---

## Brechas estratégicas y presupuestos: lo que los datos revelan y lo que falta

Los datos financieros públicos son limitados pero reveladores. La empresa reporta más de **US$100M en facturación anual** (confirmado por Semana y Las2Orillas) con **35% de crecimiento YoY**. No se han encontrado rondas de financiamiento externo — todo indica que Grupo Effi es **bootstrapped** (autofinanciado). Los presupuestos confirmados incluyen: US$1.5M+ para Feria Effix 2025, US$5.2M para EffiLiving, y un estimado de US$250K-500K anuales en publicidad digital.

La distribución estimada del presupuesto de marketing sugiere una estructura inusual: aproximadamente **60-70% en eventos y experiencial** (Feria Effix, eventos semanales, tours nacionales/internacionales, Efficaex Guatemala), **15-20% en producción de contenido** (video para YouTube, diseño para redes sociales, streaming), **10-15% en publicidad digital** (Meta Ads, native advertising) y **5-10% en PR** (una mezcla de earned media y contenido patrocinado en medios colombianos).

Existen brechas estratégicas significativas. El blog de grupoeffi.com funciona como **sala de prensa republicando artículos** de terceros, no como motor de SEO con contenido original — una oportunidad perdida de tráfico orgánico. La fragmentación en **7+ dominios** (grupoeffi.com, effi.com.co, effisystems.com, efficommerce.com, feriaeffix.com, effix.online, efficaex.efficommerce.com) diluye la autoridad de dominio. La **ausencia de app Android** es una falla crítica en un mercado donde Android domina abrumadoramente. Las reseñas mixtas de la app iOS (quejas de funcionalidad) sugieren que la experiencia móvil necesita mejora. LinkedIn prácticamente inexistente limita la captación de empresarios y tomadores de decisión B2B. Se detectaron múltiples sitios no autorizados revendiendo "La Fórmula Effix" (piratería de contenido), indicando demanda pero también pérdida de ingresos.

## Conclusión

Grupo Effi ha construido un modelo de marketing fundamentalmente diferente al de la mayoría de empresas tech: su gasto más fuerte no va a Facebook Ads sino a **crear experiencias presenciales que generan earned media, comunidad y conversión orgánica**. Feria Effix funciona como un evento-producto que simultáneamente genera ingresos (boletas + stands), leads masivos (50,000+ asistentes), cobertura de prensa gratuita en 15+ medios, y contenido redistribuible para todo el año. El verdadero insight estratégico es cómo el programa de referidos convierte el plan freemium en un motor viral — los usuarios literalmente deben referir para mantener su acceso gratuito, transformando cada cliente en un vendedor. Con **US$100M+ en facturación sin inversión externa confirmada**, el conglomerado demuestra que en mercados latinoamericanos, el community-led growth con raíces profundamente locales puede superar modelos de adquisición pagada intensiva. Las mayores oportunidades de crecimiento están en cerrar las brechas de LinkedIn y SEO, lanzar una app Android robusta, y proteger su propiedad intelectual digital de la piratería que ya erosiona el valor de La Fórmula Effix.