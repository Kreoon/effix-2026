# Feria Effix: la mayor feria de ecommerce de Latinoamérica nacida en Medellín

**Feria Effix es el evento presencial de comercio electrónico más grande de América Latina**, con casi **50.000 asistentes** en su quinta edición (agosto 2025) y un crecimiento exponencial desde sus 2.500 visitantes iniciales en 2021. Organizada por **Grupo Effi** — un conglomerado antioqueño de tecnología para ecommerce fundado por Juan David Carmona, Stevenson Rivera y Sara Montoya — la feria se celebra en **Plaza Mayor, Medellín** y combina una exposición comercial masiva con más de 300 stands, un programa académico de 160+ conferencias simultáneas en 8 auditorios, y amplios espacios de networking. Su sexta edición ya está confirmada para el **16 al 18 de octubre de 2026**. En el contexto colombiano, donde el ecommerce movió **COP $105,4 billones** en 2024, Effix se ha consolidado como el epicentro del ecosistema de emprendimiento digital, dropshipping y marketing online en la región.

---

## De la pandemia a 50.000 asistentes en cinco años

Feria Effix nació en 2021 como respuesta directa a la pandemia de COVID-19. Tres empresas antioqueñas — **El Paisa de la X**, **Effisystems** y **Efficommerce** — concibieron un espacio presencial para dinamizar el comercio electrónico en un momento crítico. Su primera edición, el **28 de noviembre de 2021**, fue un evento de un solo día que atrajo a **2.580 personas** con apenas 8 speakers y 60 marcas expositoras.

El crecimiento ha sido vertical. En 2022, la segunda edición (7-8 de octubre) duplicó el formato a dos días y quintuplicó la asistencia a **14.000 personas**. Para 2023, el salto fue radical: tres días completos (25-27 de agosto), **35.733 asistentes**, 201 speakers y 201 marcas. Ese año también tuvo una edición satélite en Ecuador (25 de febrero), marcando su expansión internacional. La cuarta edición en 2024 (2-4 de agosto, durante la Feria de las Flores) alcanzó **41.991 asistentes**, 302 marcas y 138 speakers de 15 países, generando más de **US$1 millón en negocios cerrados**. La quinta edición en agosto 2025 registró **49.256 asistentes**, 348 stands, 214 ponentes y una inversión superior a **US$1,5 millones**.

| Edición | Año | Fechas | Días | Asistentes | Marcas | Speakers |
|---------|------|--------|------|------------|--------|----------|
| 1ª | 2021 | 28 noviembre | 1 | 2.580 | 60 | 8 |
| 2ª | 2022 | 7-8 octubre | 2 | 14.000 | 106 | 18 |
| 3ª | 2023 | 25-27 agosto | 3 | 35.733 | 201 | 201 |
| 4ª | 2024 | 2-4 agosto | 3 | 41.991 | 302 | 138 |
| 5ª | 2025 | 22-24 agosto | 3 | 49.256 | 348 | 214 |
| **6ª** | **2026** | **16-18 octubre** | **3** | **Por definir** | **380+** | **180+** |

En total, más de **140.000 personas** han asistido al evento a lo largo de sus cinco ediciones. La sexta edición rompe el patrón temporal al mudarse de agosto a octubre de 2026, y ya tiene boletas a la venta a través de **LaTiquetera**.

---

## Quién está detrás: Grupo Effi y sus fundadores

El motor de Effix es **Grupo Effi**, un ecosistema empresarial con sede en el barrio Laureles de Medellín (Transversal 39B Circular 76-19). La entidad legal es **EffiX S.A.S**, NIT 901497359. El grupo integra varias verticales de negocio que atienden a **20.000 negocios en 5 países** y procesan más de **US$100 millones** en transacciones.

**Juan David Carmona Gómez** es el cofundador y rostro público del evento, responsable de la visión estratégica y vocería ante medios. **Stevenson Rivera**, emprendedor antioqueño que creó Effisystems en 2017, aporta la base tecnológica (un ERP cloud para automatización logística de ecommerce). **Sara Montoya** completa el trío fundador. Las marcas bajo el paraguas de Grupo Effi incluyen Effisystems (software ERP), Efficommerce (logística y fulfillment), Effix (la feria), Efficaex (expansión a Centroamérica con Cargo Expreso), y **EffiLiving** — un proyecto inmobiliario de US$5,2 millones en el barrio Calasanz que será el primer edificio en Colombia diseñado exclusivamente para negocios de ecommerce, con apertura prevista en 2026. El grupo opera en Colombia, Ecuador, República Dominicana, Guatemala y Costa Rica, e integra con plataformas como **Shopify, WooCommerce** y el ecosistema de mensajería de **Meta**.

Es importante señalar que Grupo Effi es simultáneamente organizador y expositor/beneficiario del evento, lo que crea una sinergia comercial directa entre la feria y sus propios productos.

---

## Qué se vive durante tres días en Plaza Mayor

La feria se realiza en **Plaza Mayor Medellín** (Cra. 57 #41-81, La Candelaria), el principal centro de convenciones de la ciudad. En la edición 2025, el evento ocupó **todos los pabellones** del recinto (Blanco, Azul, Verde, Rojo y Amarillo) con un horario de **9:00 a.m. a 8:00 p.m.** cada día. La experiencia se estructura en tres componentes principales:

**Exposición comercial.** Más de 300 marcas nacionales e internacionales exhiben productos, servicios, soluciones digitales, tecnología, logística, medios de pago y plataformas. Los expositores provienen de sectores como dropshipping, marketplaces, desarrollo web, moda, salud, educación y contabilidad digital. Empresas de Colombia, Argentina, Ecuador, China, Vietnam, Emiratos Árabes Unidos, Estados Unidos y más de 15 países participan.

**Programa académico.** La agenda educativa se segmenta en pabellones temáticos con **8 auditorios simultáneos**: el **Auditorio Effix (Pabellón Verde)** cubre liderazgo, inteligencia emocional y cultura organizacional; el **Auditorio de Marketing (Pabellón Amarillo)** se enfoca en marketing digital, ads, embudos y posicionamiento; y el **Auditorio Máster (Pabellón Rojo)** ofrece contenido avanzado en contabilidad, legal, escalamiento y estrategia global. Adicionalmente hay salas abiertas temáticas (UGC, Cámara de Comercio de Medellín, Prendas Control) y salones de networking con capacidad para 400 personas cada uno, más una zona de coworking.

**Experiencias especiales.** Las ediciones recientes han incluido masterminds con expertos, cenas privadas con ponentes, eventos de inauguración y clausura, zonas de creación de contenido, y experiencias como fire-walking (caminata sobre fuego). En 2024, durante la Feria de las Flores, hubo exhibición de autos de lujo y silletas florales.

---

## Speakers de talla internacional y temáticas clave

El cartel de ponentes ha escalado dramáticamente: de 8 speakers en 2021 a 214 en 2025. Los nombres más destacados de las últimas ediciones reflejan el enfoque multidisciplinario del evento:

- **Jürgen Klarić** (2024) — referente mundial en neuromarketing y neurociencia aplicada
- **Vilma Núñez** (2025) — experta en estrategia de marca, República Dominicana/España
- **Amadeo Lladós** (2024) — millonario español del ecommerce (Llados Fitness)
- **Gabriel Beltrán** (2025) — monetización digital global, Estados Unidos
- **Javi Rodríguez** (2025) — ventas y PNL, España
- **Rigoberto Urán** (2025) — ciclista profesional colombiano y emprendedor
- **Pablo Villegas** (2025) — Director de Marketing de **Rappi**
- **Fernando Anzures y Jorge Serratos** (2025) — marcas personales, México
- **Mike Munzvil** — fundador de MasterTools, marketing digital
- **Juan Ads, Felipe Vergara, Julián Otálora, Valentina Ortiz, Stevenson Rivera** — referentes del ecosistema digital colombiano

Las **temáticas centrales** abarcan ecommerce y tiendas online, dropshipping (tema protagonista con paneles de proveedores internacionales), marketing digital y ads (Facebook, Instagram, Google), inteligencia artificial aplicada a negocios, logística y fulfillment, creación de contenido y UGC, neuromarketing, branding personal, criptomonedas, marketplaces (Mercado Libre), importación/exportación, y formalización empresarial. El contenido está diseñado para **todos los niveles**: desde principiantes absolutos hasta emprendedores avanzados buscando escalar operaciones.

---

## Cuánto cuesta asistir y quién patrocina

Los precios han aumentado proporcionalmente al crecimiento del evento. Para la **edición 2025**, las tarifas fueron: pase de 1 día a **COP $97.450**, pasaporte de 3 días a **COP $194.800**, y VIP de 3 días desde **COP $1.120.000**. Para la **edición 2026**, el pasaporte de 3 días arranca en **COP $201.300** (IVA incluido) y la entrada Black premium alcanza **COP $1.155.000**. Los menores de 12 años entran gratis. Todas las boletas son digitales y se adquieren exclusivamente a través de **LaTiquetera** (latiquetera.com).

La experiencia **VIP** incluye entrada sin filas, zonas exclusivas con hidratación, asientos reservados en primera fila, masterminds, cena privada con ponentes, eventos de inauguración y clausura, y zonas de creación de contenido. La experiencia **Black** agrega paquete completo de alimentación (desayuno, almuerzo y cena buffet los tres días), 9 mentorías exclusivas con speakers top, zona de networking Black, descuentos en hoteles y línea de soporte dedicada.

Entre los **patrocinadores principales** a lo largo de las ediciones figuran **MercadoLibre**, **Mercado Pago**, **Envía**, **TCC**, **Servientrega**, **Inter Rapidísimo**, **Coordinadora**, **Taboola**, **SmartBeemo**, **MasterTools**, **Xhobbies**, **Comfama**, **Dropi** y **ROOT+CO**. El evento cuenta con respaldo institucional de la **Alcaldía de Medellín**, la **Gobernación de Antioquia** y la **Cámara de Comercio de Medellín**, con 28 entidades públicas y privadas apoyando la edición 2024. Un dato relevante: Effix opera **de manera independiente** de la Cámara Colombiana de Comercio Electrónico (CCCE), que organiza sus propios eventos como el eCommerce Day Colombia.

---

## Presencia digital y cobertura mediática

Effix tiene una presencia en redes sociales notable para un evento regional. Su cuenta de **Instagram (@feriaeffix)** acumula más de **382.000 seguidores** — una cifra considerable que supera a muchos eventos de ecommerce globales. En **TikTok (@feriaeffix)** tiene **30.300 seguidores** y 217.000 likes. Mantiene presencia activa en **Facebook, YouTube, LinkedIn y WhatsApp**. En YouTube alberga más de **110 videos** de conferencias grabadas de todas las ediciones (4 de 2021, 11 de 2022, 22 de 2023, 37 de 2024, 37 de 2025). El sitio web oficial es **feriaeffix.com**, y el contacto directo es **gerencia@feriaeffix.com** o **+57 320 655 6725**.

La cobertura mediática incluye los principales medios colombianos: **El Tiempo, El Colombiano, Portafolio, La República, Pulzo, RCN Radio, Teleantioquia, Valora Analitik, Las2Orillas**, entre otros. En medios especializados aparece en **Marketing4eCommerce.co** y **America Retail**. A nivel internacional en inglés, está listada en **MedellinGuru**, **N Trade Shows** y **Neventum**. Grupo Effi también vende un infoproducto en Hotmart llamado **"La Fórmula Effix"** — un curso digital sobre crecimiento de negocios digitales y dropshipping en Colombia, con rating de 4,4/5.

---

## El impacto económico y su posición en el ecosistema colombiano

Effix opera en un mercado en pleno auge. Colombia es la **tercera potencia de ecommerce en Latinoamérica** (detrás de Brasil y México), y el primer semestre de 2025 registró COP $27,3 billones en ventas online con un crecimiento del **16,4% interanual**. La edición 2025 de Effix generó un impacto económico proyectado de **US$23,1 millones** para Medellín según el Sistema de Inteligencia Turística (SIT), creó **1.200 empleos directos y 3.627 indirectos**, y facilitó una derrama económica superior a **US$3 millones**.

Comparada con otros eventos del ecosistema, Effix domina en escala de asistencia. El **eCommerce Day Colombia** (organizado por el eCommerce Institute y la CCCE) atrajo 2.350 profesionales en 2025 — menos del 5% de la asistencia de Effix. Sin embargo, los perfiles son diferentes: eCommerce Day apunta a ejecutivos corporativos e institucionales, mientras que Effix captura al universo más amplio de **emprendedores, dropshippers, creadores de contenido y comerciantes digitales** de todos los niveles. Esta diferenciación explica tanto su masividad como su relevancia particular para el emprendedor de ecommerce y dropshipping en Colombia.

---

## Conclusión

Feria Effix representa un fenómeno singular en el ecosistema digital latinoamericano: un evento que pasó de cero a casi 50.000 asistentes en cinco años, nacido de la necesidad pandémica y sostenido por la explosión del ecommerce y el dropshipping en Colombia. Para un emprendedor de ecommerce en Medellín, Effix es **el evento de referencia obligada** — no solo por su escala, sino por su concentración de proveedores, logística, formación y networking específicamente diseñados para el modelo de negocio digital. La próxima edición (**16-18 de octubre de 2026**, Plaza Mayor) ya está en preventa, y el cambio de fecha de agosto a octubre sugiere una estrategia de diferenciación respecto a la Feria de las Flores. Un dato a considerar: dado que Grupo Effi es simultáneamente organizador, expositor y vendedor de soluciones tecnológicas, la feria funciona también como un ecosistema comercial integrado — algo que es a la vez su fortaleza competitiva y un factor que el asistente debe tener en cuenta al evaluar la información que recibe durante el evento.